package gre.lab2.gui.impl;

public final class CanceledAnimationException extends RuntimeException {}
